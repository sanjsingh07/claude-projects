import React, { useState, useEffect } from 'react';
import { View, ScrollView, StyleSheet, ActivityIndicator, TouchableOpacity, Alert, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { StellarCard, StellarText } from '@components/StellarCard';
import { StellarBackground } from '@components/StellarBackground';
import { SignIcon } from '@components/SignIcon';
import { VedicChartCard, VedicChartSelector } from '@components/VedicChartCard';
import { useAuthStore } from '@store/authStore';
import { colors, spacing } from '@theme/theme';
import { useQuery, useMutation } from '@tanstack/react-query';
import { api } from '@services/api';
import { useVedicChart } from '@hooks/useVedicChart';
import { DivisionalChartType } from '@types';

// Planet configuration
const PLANETS = [
  { name: 'Sun', key: 'sun' },
  { name: 'Moon', key: 'moon' },
  { name: 'Mercury', key: 'mercury' },
  { name: 'Venus', key: 'venus' },
  { name: 'Mars', key: 'mars' },
  { name: 'Jupiter', key: 'jupiter' },
  { name: 'Saturn', key: 'saturn' },
  { name: 'Uranus', key: 'uranus' },
  { name: 'Neptune', key: 'neptune' },
  { name: 'Pluto', key: 'pluto' },
] as const;

interface PlanetPosition {
  planet: string;
  sign: string;
  degree: number;
  retrograde: boolean;
  house?: number;
}

interface NatalChartData {
  sunSign: string;
  moonSign: string;
  risingSign: string;
  planetaryPositions: PlanetPosition[];
  houses: any[];
  aspects: any[];
}

export const ChartScreen: React.FC = () => {
  const user = useAuthStore((s) => s.user);
  const {
    natalChart: vedicNatalChart,
    selectedDivisionalChart,
    divisionalCharts,
    nakshatra,
    getVedicChart,
    selectDivisionalChart,
  } = useVedicChart();
  const [showVedic, setShowVedic] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Query for Western natal chart
  const {
    data: chart,
    isLoading: isChartLoading,
    error: chartError,
    refetch: refetchChart,
  } = useQuery<NatalChartData>({
    queryKey: ['natalChart', user?.id],
    queryFn: async () => {
      const response = await api.getNatalChart();
      return response.data as NatalChartData;
    },
    enabled: !!user?.id,
    retry: false,
  });

  // Mutation to calculate Western chart
  const calculateWesternChart = useMutation({
    mutationFn: async () => {
      const response = await api.recalculateChart();
      return response.data as NatalChartData;
    },
    onSuccess: () => {
      refetchChart();
    },
  });

  // Mutation to load existing Vedic chart without recalculating or overwriting stored chart data
  const loadVedic = useMutation({
    mutationFn: async () => {
      return getVedicChart();
    },
  });

  // Auto-calculate Western chart if missing
  useEffect(() => {
    if (user?.id && !chart && !isChartLoading && !calculateWesternChart.isPending) {
      Alert.alert(
        'No Natal Chart',
        'Your natal chart has not been calculated yet. Would you like to calculate it now?',
        [
          {
            text: 'Cancel',
            style: 'cancel',
          },
          {
            text: 'Calculate',
            onPress: () => calculateWesternChart.mutate(),
          },
        ]
      );
    }
  }, [user?.id, chart, isChartLoading]);

  const handleToggleVedic = async () => {
    if (showVedic) {
      setShowVedic(false);
    } else {
      try {
        if (!Object.values(divisionalCharts).some(Boolean)) {
          await loadVedic.mutateAsync();
        }
        setShowVedic(true);
      } catch (err: any) {
        Alert.alert('Error', 'Failed to load Vedic chart. Please try again.');
      }
    }
  };

  const handleSelectChart = (type: DivisionalChartType) => {
    selectDivisionalChart(type);
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      if (showVedic) {
        await getVedicChart();
      } else {
        await refetchChart();
      }
    } finally {
      setIsRefreshing(false);
    }
  };

  const isLoading = isChartLoading || calculateWesternChart.isPending;
  const isVedicLoadingState = loadVedic.isPending;

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <StellarBackground />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.white} />
          <StellarText variant="body" style={{ marginTop: spacing.md, color: colors.gray400 }}>
            Loading your natal chart...
          </StellarText>
        </View>
      </SafeAreaView>
    );
  }

  if (chartError || !chart) {
    return (
      <SafeAreaView style={styles.container}>
        <StellarBackground />
        <View style={styles.emptyContainer}>
          <Ionicons name="cloud-outline" size={64} color={colors.gray600} />
          <StellarText variant="heading3" style={{ marginTop: spacing.lg, color: colors.gray400 }}>
            No Natal Chart
          </StellarText>
          <StellarText variant="body" style={{ marginTop: spacing.sm, color: colors.gray500, textAlign: 'center' }}>
            Your natal chart hasn't been calculated yet.
          </StellarText>
          <TouchableOpacity
            style={styles.calculateButton}
            onPress={() => calculateWesternChart.mutate()}
          >
            <StellarText style={styles.calculateButtonText}>Calculate Chart</StellarText>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // Get planet position from array
  const getPlanetPosition = (planetKey: string): PlanetPosition | undefined => {
    if (!Array.isArray(chart.planetaryPositions)) {
      return undefined;
    }
    return chart.planetaryPositions.find(
      (p) => p.planet?.toLowerCase() === planetKey.toLowerCase()
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <StellarBackground />
      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefreshing}
            onRefresh={handleRefresh}
            tintColor={colors.white}
            colors={[colors.white]}
            progressBackgroundColor={colors.gray900}
            title="Refreshing chart..."
            titleColor={colors.gray400}
          />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <StellarText variant="heading2" uppercase>
            {showVedic ? 'Vedic Chart' : 'Your Natal Chart'}
          </StellarText>
          <TouchableOpacity style={styles.toggleButton} onPress={handleToggleVedic}>
            <StellarText variant="body" style={styles.toggleButtonText}>
              {showVedic ? 'Show Western' : 'Show Vedic'}
            </StellarText>
            <Ionicons
              name={showVedic ? 'ellipse-outline' : 'analytics-outline'}
              size={20}
              color={colors.white}
              style={{ marginLeft: 8 }}
            />
          </TouchableOpacity>
        </View>

        {isRefreshing && (
          <View style={styles.refreshStatus}>
            <ActivityIndicator size="small" color={colors.white} />
            <StellarText variant="bodySmall" style={styles.refreshStatusText}>
              {showVedic ? 'Refreshing Vedic chart...' : 'Refreshing natal chart...'}
            </StellarText>
          </View>
        )}

        {showVedic ? (
          // Vedic Chart View
          <View>
            {isVedicLoadingState && (
              <View style={styles.loadingContainer}>
                <ActivityIndicator size="small" color={colors.accent} />
                <StellarText variant="body" style={{ marginTop: spacing.sm, color: colors.gray400 }}>
                  Calculating Vedic chart...
                </StellarText>
              </View>
            )}

            <VedicChartSelector
              selectedChart={selectedDivisionalChart}
              onSelectChart={handleSelectChart}
            />

            {selectedDivisionalChart && divisionalCharts[selectedDivisionalChart] ? (
              <VedicChartCard
                key={selectedDivisionalChart}
                chart={divisionalCharts[selectedDivisionalChart]!}
                nakshatra={nakshatra}
              />
            ) : divisionalCharts.D1 ? (
              <VedicChartCard
                chart={divisionalCharts.D1}
                nakshatra={nakshatra}
              />
            ) : !isVedicLoadingState ? (
              <StellarCard variant="bordered">
                <StellarText>Tap a chart type above to view</StellarText>
              </StellarCard>
            ) : null}

            {nakshatra && (
              <StellarCard variant="bordered" style={styles.card}>
                <StellarText variant="label" style={styles.cardTitle}>
                  Your Nakshatra
                </StellarText>
                <View style={styles.nakshatraInfo}>
                  <View style={styles.nakshatraRow}>
                    <StellarText variant="body" style={styles.nakshatraLabel}>Name:</StellarText>
                    <StellarText variant="body" style={styles.nakshatraValue}>{nakshatra.name}</StellarText>
                  </View>
                  <View style={styles.nakshatraRow}>
                    <StellarText variant="body" style={styles.nakshatraLabel}>Pada:</StellarText>
                    <StellarText variant="body" style={styles.nakshatraValue}>{nakshatra.pada}</StellarText>
                  </View>
                  <View style={styles.nakshatraRow}>
                    <StellarText variant="body" style={styles.nakshatraLabel}>Lord:</StellarText>
                    <StellarText variant="body" style={styles.nakshatraValue}>{nakshatra.lord}</StellarText>
                  </View>
                </View>
              </StellarCard>
            )}
          </View>
        ) : (
          // Western Chart View
          <>
            {/* Big Three Card */}
            <StellarCard variant="bordered" style={styles.card}>
              <StellarText variant="label" style={styles.cardTitle}>
                The Big Three
              </StellarText>
              <View style={styles.bigThree}>
                <View style={styles.bigThreeItem}>
                  <SignIcon sign={chart.sunSign?.toLowerCase() as any} size={32} color={colors.white} />
                  <StellarText variant="caption" color={colors.gray500} style={{ marginTop: spacing.xs }}>
                    Sun
                  </StellarText>
                  <StellarText variant="body" style={{ marginTop: spacing.sm, textTransform: 'capitalize' }}>
                    {chart.sunSign}
                  </StellarText>
                </View>
                <View style={styles.bigThreeItem}>
                  <SignIcon sign={chart.moonSign?.toLowerCase() as any} size={32} color={colors.white} />
                  <StellarText variant="caption" color={colors.gray500} style={{ marginTop: spacing.xs }}>
                    Moon
                  </StellarText>
                  <StellarText variant="body" style={{ marginTop: spacing.sm, textTransform: 'capitalize' }}>
                    {chart.moonSign}
                  </StellarText>
                </View>
                <View style={styles.bigThreeItem}>
                  <SignIcon sign={chart.risingSign?.toLowerCase() as any} size={32} color={colors.white} />
                  <StellarText variant="caption" color={colors.gray500} style={{ marginTop: spacing.xs }}>
                    Rising
                  </StellarText>
                  <StellarText variant="body" style={{ marginTop: spacing.sm, textTransform: 'capitalize' }}>
                    {chart.risingSign}
                  </StellarText>
                </View>
              </View>
            </StellarCard>

            {/* Planetary Positions Card */}
            <StellarCard variant="bordered" style={styles.card}>
              <StellarText variant="label" style={styles.cardTitle}>
                Planetary Positions
              </StellarText>
              {PLANETS.map((planet) => {
                const position = getPlanetPosition(planet.key);
                if (!position) return null;
                return (
                  <View key={planet.key} style={styles.planetRow}>
                    <StellarText variant="body" style={styles.planetName}>
                      {planet.name}
                    </StellarText>
                    <View style={styles.planetSign}>
                      <SignIcon sign={position.sign?.toLowerCase() as any} size={16} color={colors.gray400} />
                      <StellarText variant="bodySmall" style={{ marginLeft: spacing.sm, textTransform: 'capitalize' }}>
                        {position.sign} {position.degree}°
                      </StellarText>
                    </View>
                  </View>
                );
              })}
            </StellarCard>
          </>
        )}

        <View style={styles.bottomSpacing} />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.black,
  },
  content: {
    flex: 1,
    paddingHorizontal: spacing.lg,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.xl,
  },
  header: {
    paddingVertical: spacing.lg,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  toggleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    backgroundColor: colors.gray900,
    borderRadius: 20,
  },
  toggleButtonText: {
    color: colors.white,
  },
  refreshStatus: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    backgroundColor: colors.gray900,
    borderWidth: 1,
    borderColor: colors.gray800,
    borderRadius: 20,
  },
  refreshStatusText: {
    marginLeft: spacing.sm,
    color: colors.gray400,
  },
  card: {
    marginBottom: spacing.lg,
  },
  cardTitle: {
    marginBottom: spacing.lg,
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.gray800,
  },
  bigThree: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  bigThreeItem: {
    alignItems: 'center',
  },
  planetRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.gray800,
  },
  planetName: {
    color: colors.white,
  },
  planetSign: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  nakshatraInfo: {
    paddingVertical: spacing.sm,
  },
  nakshatraRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: spacing.xs,
  },
  nakshatraLabel: {
    color: colors.gray500,
  },
  nakshatraValue: {
    color: colors.white,
    textTransform: 'capitalize',
  },
  bottomSpacing: {
    height: spacing['3xl'],
  },
  calculateButton: {
    marginTop: spacing.lg,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    backgroundColor: colors.accent,
    borderRadius: 8,
  },
  calculateButtonText: {
    color: colors.white,
    fontWeight: 'bold',
  },
});

export default ChartScreen;
