import React from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  StatusBar,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { DateTime } from 'luxon';

import { 
  StellarText, 
  MoodRing, 
  TransitCard, 
  AspectList,
  StellarBackground,
  GenerationInfoModal
} from '@components';
import { useHoroscope } from '@hooks/useHoroscope';
import { colors } from '@theme/theme';
import { DailyHoroscope } from '@types';

export const TodayScreen: React.FC = () => {
  const { todayHoroscope, refresh, isLoading } = useHoroscope();
  const horoscope = todayHoroscope as DailyHoroscope | null;
  const [showInfo, setShowInfo] = React.useState(false);

  const headerDate = horoscope?.forDate
    ? DateTime.fromISO(horoscope.forDate)
    : DateTime.now();
  const dayName = headerDate.toFormat('cccc').toUpperCase();
  const fullDate = headerDate.toFormat('MMMM d, yyyy');

  // Default data for when horoscope is loading or missing fields
  const moodAspects = horoscope?.moodAspects || {
    emotion: '...',
    career: '...',
    love: '...',
    health: '...',
  };

  const moodAspectsList = [
    { key: 'Emotion', val: moodAspects.emotion, highlight: moodAspects.emotion === 'intense' || moodAspects.emotion === 'rising' },
    { key: 'Career', val: moodAspects.career, highlight: moodAspects.career === 'intense' || moodAspects.career === 'rising' },
    { key: 'Love', val: moodAspects.love, highlight: moodAspects.love === 'intense' || moodAspects.love === 'rising' },
    { key: 'Health', val: moodAspects.health, highlight: moodAspects.health === 'intense' || moodAspects.health === 'rising' },
  ];

  const primaryTransit = horoscope?.primaryTransit || {
    title: 'Calculating transits...',
    badge: 'minor' as const,
    planets: '...',
    body: 'Please wait while we align with the stars.',
    source: '1 of ? active transits',
  };

  const aspects = horoscope?.aspects || [];

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" />
      <StellarBackground />

      {/* Date Header */}
      <View style={styles.header}>
        <View style={styles.dateInfo}>
          <StellarText style={styles.dayText}>TODAY · {dayName}</StellarText>
          <StellarText style={styles.fullDateText} serif>{fullDate}</StellarText>
        </View>
        <TouchableOpacity 
          style={styles.infoButton} 
          onPress={() => setShowInfo(true)}
          activeOpacity={0.7}
        >
          <StellarText style={styles.infoIcon}>i</StellarText>
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={refresh}
            tintColor={colors.stellarFg}
          />
        }
      >
        {/* Mood Section */}
        <MoodRing
          score={horoscope?.energyScore || 0}
          label="Your day at a glance"
          aspects={moodAspectsList}
        />

        {/* Primary Transit Card */}
        <TransitCard
          title={primaryTransit.title}
          badge={primaryTransit.badge}
          planets={primaryTransit.planets}
          body={primaryTransit.body}
          source={primaryTransit.source}
          isLoading={isLoading && !horoscope}
        />

        {/* Aspects List */}
        {aspects.length > 0 && (
          <AspectList
            label="Today's aspects"
            aspects={aspects}
          />
        )}
        
        {/* Bottom Spacing */}
        <View style={styles.bottomSpacing} />
      </ScrollView>

      <GenerationInfoModal
        visible={showInfo}
        onClose={() => setShowInfo(false)}
        horoscope={horoscope}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.stellarBg,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.stellarBorder,
  },
  dateInfo: {
    flexDirection: 'column',
  },
  dayText: {
    fontSize: 11,
    letterSpacing: 2,
    textTransform: 'uppercase',
    color: colors.stellarMuted,
    marginBottom: 2,
    fontFamily: 'DM Sans',
  },
  fullDateText: {
    fontSize: 19,
    color: colors.stellarFg,
    // textAlign: 'center',
    fontFamily: 'Instrument Serif',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoButton: {
    width: 38,
    height: 38,
    backgroundColor: colors.stellarSurface,
    borderWidth: 1.5,
    borderColor: colors.stellarViolet + '60',
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: colors.stellarViolet,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  infoIcon: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.stellarViolet,
    fontFamily: 'Instrument Serif',
    fontStyle: 'italic',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    paddingTop: 20,
    paddingHorizontal: 24,
    paddingBottom: 34,
  },
  bottomSpacing: {
    height: 40,
  },
});

export default TodayScreen;
